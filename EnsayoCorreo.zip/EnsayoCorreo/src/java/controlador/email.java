/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.Properties;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author Usuario
 */
@Named(value = "email")
@RequestScoped
public class email {

    private String correo;
    
    private String mensaje;

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }


    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public email() {
    }
    
    public void enviarMensaje(){
        try {
            Properties prop = new Properties();
            prop.setProperty("mail.smtp.host", "smtp.gmail.com");
            prop.setProperty("mail.smtp.starttls.enable", "true");
            prop.setProperty("mail.smtp.port", "587");
            prop.setProperty("mail.smtp.auth", "true");
            prop.setProperty("mail.from", this.getCorreo());
            
            Session session = Session.getDefaultInstance(prop);
            
            String correoRemitente = "jscely85@misena.edu.co";
            String contraseña = "elholaquehace26";
            String correoReceptor = this.getCorreo();
            String comentario = this.getMensaje();
            MimeMessage message = new MimeMessage(session);
            message.setFrom("sebascely68@gmail.com");
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(correoRemitente));
            message.setText(comentario);
            Transport t = session.getTransport("smtp");
            t.connect(correoRemitente, contraseña);
            t.sendMessage(message, message.getRecipients(Message.RecipientType.TO));
            t.close();
            System.out.println(correoReceptor);
            System.out.println("Correo enviado exitosamente");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
